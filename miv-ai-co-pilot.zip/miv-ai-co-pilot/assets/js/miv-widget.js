(function () {
  const backendUrl =
    (window.MIV_WIDGET_CONFIG && window.MIV_WIDGET_CONFIG.backendUrl) ||
    "http://localhost:8000";

  let fontScale = 1;
  let highContrast = false;
  let isLoading = false;

  const QUICK_QUESTIONS = [
    "How do I make sure my online forms are accessible?",
    "What tools can help someone with low vision use my digital content more easily?",
    "How do I make my event more accessible for people with different disabilities?",
    "Can you help me find tools to support people with hearing impairments?"
  ];

  const root = document.getElementById("miv-widget-root");
  if (!root) return;

  const launcherBtn = document.getElementById("miv-launcher-btn");
  const chatWindow = document.getElementById("miv-chat-window");
  const closeBtn = document.getElementById("miv-close-btn");

  const a11yToggle = document.getElementById("miv-a11y-toggle");
  const a11yPanel = document.getElementById("miv-a11y-panel");
  const a11yClose = document.getElementById("miv-a11y-close");

  const fontDec = document.getElementById("miv-font-dec");
  const fontInc = document.getElementById("miv-font-inc");
  const contrastToggle = document.getElementById("miv-contrast-toggle");

  const messagesEl = document.getElementById("miv-messages");
  const form = document.getElementById("miv-form");
  const input = document.getElementById("miv-user-input");

  /* -----------------------------
     Quick Questions UI
  ----------------------------- */
  const quickWrap = document.createElement("div");
  quickWrap.className = "miv-quick-questions";

  QUICK_QUESTIONS.forEach(q => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "miv-chip";
    btn.innerHTML = `<span class="miv-chip-text">${q}</span>`;

    btn.addEventListener("click", () => {
      input.value = q;
      input.focus();
      sendMessage(q);
    });

    quickWrap.appendChild(btn);
  });

  chatWindow.insertBefore(quickWrap, messagesEl);

  /* -----------------------------
     Rendering helpers (ChatGPT-style)
  ----------------------------- */
  function addMessage(role, text) {
    const wrapper = document.createElement("div");
    wrapper.className = "miv-message miv-message--" + role;

    const lines = text
      .split("\n")
      .map(l => l.trim())
      .filter(Boolean);

    let listEl = null;

    lines.forEach(line => {
      if (line.startsWith("## ")) {
        const h = document.createElement("h4");
        h.textContent = line.replace(/^##\s*/, "");
        wrapper.appendChild(h);
        listEl = null;
        return;
      }

      if (line.startsWith("### ")) {
        const h = document.createElement("h5");
        h.textContent = line.replace(/^###\s*/, "");
        wrapper.appendChild(h);
        listEl = null;
        return;
      }

      if (line.startsWith("- ") || line.startsWith("• ")) {
        if (!listEl || listEl.tagName !== "UL") {
          listEl = document.createElement("ul");
          wrapper.appendChild(listEl);
        }
        const li = document.createElement("li");
        li.textContent = line.replace(/^[-•]\s*/, "");
        listEl.appendChild(li);
        return;
      }

      if (/^\d+\.\s+/.test(line)) {
        if (!listEl || listEl.tagName !== "OL") {
          listEl = document.createElement("ol");
          wrapper.appendChild(listEl);
        }
        const li = document.createElement("li");
        li.textContent = line.replace(/^\d+\.\s+/, "");
        listEl.appendChild(li);
        return;
      }

      listEl = null;
      const p = document.createElement("p");
      p.textContent = line;
      wrapper.appendChild(p);
    });

    messagesEl.appendChild(wrapper);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addTypingIndicator() {
    const wrapper = document.createElement("div");
    wrapper.className =
      "miv-message miv-message--assistant miv-message--typing";
    wrapper.id = "miv-typing";

    for (let i = 0; i < 3; i++) {
      const dot = document.createElement("span");
      dot.className = "miv-dot";
      wrapper.appendChild(dot);
    }

    messagesEl.appendChild(wrapper);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function removeTypingIndicator() {
    const el = document.getElementById("miv-typing");
    if (el) el.remove();
  }

  /* -----------------------------
     Accessibility controls
  ----------------------------- */
  function applyFontScale() {
    chatWindow.style.setProperty("--miv-font-scale", fontScale.toString());
  }

  function applyContrast() {
    chatWindow.classList.toggle(
      "miv-chat-window--high-contrast",
      highContrast
    );
    contrastToggle.setAttribute("aria-pressed", highContrast);
  }

  /* -----------------------------
     Chat controls
  ----------------------------- */
  function openChat() {
    chatWindow.classList.add("miv-chat-window--open");
    chatWindow.setAttribute("aria-hidden", "false");
    launcherBtn.style.display = "none";
    input.focus();
  }

  function closeChat() {
    chatWindow.classList.remove("miv-chat-window--open");
    chatWindow.setAttribute("aria-hidden", "true");
    launcherBtn.style.display = "";
  }

  async function sendMessage(text) {
    if (!text || isLoading) return;
    isLoading = true;

    quickWrap.style.display = "none";
    addMessage("user", text);
    addTypingIndicator();

    try {
      const res = await fetch(backendUrl + "/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text, top_k: 3 })
      });

      const data = await res.json();
      removeTypingIndicator();
      addMessage(
        "assistant",
        data.response || "I couldn’t generate a response just now."
      );
    } catch (err) {
      console.error(err);
      removeTypingIndicator();
      addMessage(
        "assistant",
        "I ran into a technical issue talking to the server."
      );
    } finally {
      isLoading = false;
    }
  }

  /* -----------------------------
     Event listeners
  ----------------------------- */
  launcherBtn.addEventListener("click", openChat);
  closeBtn.addEventListener("click", closeChat);

  a11yToggle.addEventListener("click", () => {
    a11yPanel.toggleAttribute("hidden");
  });

  a11yClose.addEventListener("click", () => {
    a11yPanel.setAttribute("hidden", "true");
  });

  fontDec.addEventListener("click", () => {
    fontScale = Math.max(0.9, fontScale - 0.1);
    applyFontScale();
  });

  fontInc.addEventListener("click", () => {
    fontScale = Math.min(1.2, fontScale + 0.1);
    applyFontScale();
  });

  contrastToggle.addEventListener("click", () => {
    highContrast = !highContrast;
    applyContrast();
  });

  form.addEventListener("submit", e => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    sendMessage(text);
  });

  /* -----------------------------
     Initial message
  ----------------------------- */
  addMessage(
    "assistant",
    "Ask me anything about accessibility, inclusive ventures, or supporting people with disabilities."
  );

  applyFontScale();
  applyContrast();
})();
